import scrapy
import mysql.connector
import json
mydb = mysql.connector.connect(
  host="dbMysql",
  port="3306",
  user="rdd",
  password="rddtest",
  database="amazondata",
)
mycursor = mydb.cursor()
class AmmaSpider(scrapy.Spider):
    name = 'amma'
    def __init__(self,filename=None):
        if filename:
            with open(filename, 'r') as f:
                self.start_urls = f.readlines() 
    #     super(AmmaSpider,self).__init__(*args,**kwargs)
    #     self.urls=[kwargs.get('start_url')]
    # def start_requests(self):
    #     for url in urls:
    #         yield scrapy.Request(url)
    
    def parse(self, response):
        for quote in response.css('div#dp-container'):
            
            title=quote.css('span.a-size-large::text').get()
            title=title.replace('\n','')
            title=title.strip()
            price=None
            if(quote.css('span#priceblock_ourprice::text').get()!=None):
                price=quote.css('span#priceblock_ourprice::text').get()
            elif(quote.css('span#priceblock_saleprice::text').get()!=None):
                price=quote.css('span#priceblock_saleprice::text').get()
            if(price!=None):
                price=price.replace('\u20b9','')
                price=price.replace('\u00a0','')
                price=price.strip()
            rating=quote.xpath('//span[@class="reviewCountTextLinkedHistogram noUnderline"]/@title').extract()
            if len(rating)!=0:
                rating=rating[0].split(" ")[0]
                NoOfRating=quote.css("span#acrCustomerReviewText::text").get()
                NoOfRating=NoOfRating.split(" ")[0]
            else:
                rating=None
                NoOfRating=None
            
            product_info=dict()
            
            for row in quote.xpath('//div[@class="pdTab"]//table//tbody//tr'):
                if(row.xpath('td[1]//text()').extract_first()!='\xa0'):
                    label=row.xpath('td[1]//text()').extract_first()
                    value=row.xpath('td[2]//text()').extract_first()
                    label=(label.strip()).replace('\n','')
                    value=(value.strip()).replace('\n','')
                    product_info[label]=value
            
            listprice=quote.css('span.priceBlockStrikePriceString::text').get()
            if listprice!=None:
                listprice=listprice.replace('\u20b9','')
                listprice=listprice.replace('\u00a0','')
                listprice=listprice.strip()
            isamazonchoice= quote.css('span.ac-badge-text-primary::text').get()
            if isamazonchoice!=None:
                amazonchoice="Yes"
                AmazonChoiceSearchTerm=quote.xpath('//span[@class="ac-keyword-link"]//a//text()').extract()
                AmazonChoiceSearchTerm=AmazonChoiceSearchTerm[0]
            else:
                amazonchoice="No"
                AmazonChoiceSearchTerm=None
            isbestseller=quote.css('i.p13n-best-seller-badge::text').get()
            if isbestseller!=None:
                bestseller="Yes"
                bscat=quote.xpath('//a[@class="badge-link"]//span[@class="cat-name"]//span[@class="cat-link"]//text()').extract()
                bestsellercategory=bscat[0]
            else:
                bestseller="No"
                bestsellercategory= None

            
            x=[]
           
            for imglst in response.xpath('//div[@id="altImages"]'):
                x=imglst.css("img").xpath('@src').getall()    
            # yield {
            #     'text':title,
            #     'price':price,
            #     'image_url':x,
            #     'rating':rating,
            #     'list price':listprice,
            #     'product info':product_info,
            #     'Amazon Choice':amazonchoice,
            #     'isbestseller':bestseller,
            #     'bestsellercategory':bestsellercategory,
            #     'NoOfRating':NoOfRating,
            #     'AmazonChoiceSearchTerm':AmazonChoiceSearchTerm,
            #     }
            product_info=json.dumps(product_info)  
            imgurl=','.join(str(y) for y in x) 
            sql = "INSERT INTO `productdata`(`product_name`, `list_price`, `price`, `rating`, `no_of_review`, `product_info`, `isamazonchoice`, `amazonsearchterm`, `isbestseller`, `bestsellercategory`, `image_url`) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
            val = (title,listprice,price,rating,NoOfRating,product_info,amazonchoice,AmazonChoiceSearchTerm,bestseller,bestsellercategory,imgurl)
            mycursor.execute(sql, val)
            mydb.commit()