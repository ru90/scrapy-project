import scrapy
from urllib import parse
# import mysql.connector
import json
# mydb = mysql.connector.connect(
#   host="dbMysql",
#   port="3306",
#   user="rdd",
#   password="rddtest",
#   database="amazondata"
# )
# mycursor = mydb.cursor()
class Amma1Spider(scrapy.Spider):
    name = 'amma1'
    def __init__(self,*args, **kwargs):
        super(Amma1Spider,self).__init__(*args,**kwargs)
        self.start_urls=[kwargs.get('start_url')]
    
    
    def parse(self, response):
        f=open("paginationlinks.txt","w")
        f.write(response.url+"\n")
        f.close()
        yield scrapy.Request(response.urljoin(response.url), callback=self.parse_detaild_page_link, dont_filter=True)
        yield scrapy.Request(response.url,callback=self.pagination_link_extraction,dont_filter=True)
        
        # for quote in response.css('div.sg-col-inner'):
        #     listprods = quote.xpath('//div[@class="a-section a-spacing-medium"]')
        #     for listprod in listprods:
        #        for link in listprod.xpath('//h2[@class="a-size-mini a-spacing-none a-color-base s-line-clamp-4"]//a[@class="a-link-normal a-text-normal"]//@href'):
        #             link=link.extract()
        #             detail_url=parse.urljoin("https://www.amazon.com",link)
        #             f.write(detail_url+"\n")
            
        #             # print(detail_url)
        #             # yield scrapy.Request(detail_url, callback=self.parse_link)
        #             # yield scrapy.Request(response.urljoin(link),callback=self.parse_link)
        # print("length",len(listprods))
        
    def pagination_link_extraction(self,response):
        
        s_link_pg=response.xpath('//li[@class="a-last"]//a//@href').extract_first()
        if(s_link_pg!=None):
            # print("helloo",s_link_pg)
            f=open("paginationlinks.txt","a")
            f.write("https://www.amazon.com"+s_link_pg+"\n")
            f.close()
            yield scrapy.Request(response.urljoin(s_link_pg), callback=self.parse_detaild_page_link, dont_filter=True)
            yield scrapy.Request(response.urljoin(s_link_pg), callback=self.pagination_link_extraction, dont_filter=True)
        else:
            yield None


    def parse_detaild_page_link(self,response):
        f = open('links.txt',"a")
        
        for link in response.xpath('//h2[@class="a-size-mini a-spacing-none a-color-base s-line-clamp-4"]//a[@class="a-link-normal a-text-normal"]/@href'):
            # print(link.extract())
            detail_url=parse.urljoin("https://www.amazon.com",link.extract())
            f.write(detail_url+"\n")
            # yield scrapy.Request(response.urljoin(link.extract()),callback=self.parse_link)
        f.close()
    # def parse_link(self, response):
    #     for quote in response.css('div#dp-container'):
    #         title=quote.css('span.a-size-large::text').get()
    #         title=title.replace('\n','')
    #         title=title.strip()
    #         price=None
    #         if(quote.css('span#priceblock_ourprice::text').get()!=None):
    #             price=quote.css('span#priceblock_ourprice::text').get()
    #         elif(quote.css('span#priceblock_saleprice::text').get()!=None):
    #             price=quote.css('span#priceblock_saleprice::text').get()
    #         if(price!=None):
    #             price=price.replace('\u20b9','')
    #             price=price.replace('\u00a0','')
    #             price=price.strip()
    #         rating=quote.xpath('//span[@class="reviewCountTextLinkedHistogram noUnderline"]/@title').extract()
    #         if len(rating)!=0:
    #             rating=rating[0].split(" ")[0]
    #             NoOfRating=quote.css("span#acrCustomerReviewText::text").get()
    #             NoOfRating=NoOfRating.split(" ")[0]
    #         else:
    #             rating=None
    #             NoOfRating=None
    #         product_info=dict()
            
    #         for row in quote.xpath('//div[@class="pdTab"]//table//tbody//tr'):
    #             if(row.xpath('td[1]//text()').extract_first()!='\xa0'):
    #                 label=row.xpath('td[1]//text()').extract_first()
    #                 value=row.xpath('td[2]//text()').extract_first()
    #                 label=(label.strip()).replace('\n','')
    #                 value=(value.strip()).replace('\n','')
    #                 product_info[label]=value
                
    #         listprice=quote.css('span.priceBlockStrikePriceString::text').get()
    #         if listprice!=None:
    #             listprice=listprice.replace('\u20b9','')
    #             listprice=listprice.replace('\u00a0','')
    #             listprice=listprice.strip()
    #         isamazonchoice= quote.css('span.ac-badge-text-primary::text').get()
    #         if isamazonchoice!=None:
    #             amazonchoice="Yes"
    #             AmazonChoiceSearchTerm=quote.xpath('//span[@class="ac-keyword-link"]//a//text()').extract()
    #             AmazonChoiceSearchTerm=AmazonChoiceSearchTerm[0]
    #         else:
    #             amazonchoice="No"
    #             AmazonChoiceSearchTerm=None
    #         isbestseller=quote.css('i.p13n-best-seller-badge::text').get()
    #         if isbestseller!=None:
    #             bestseller="Yes"
    #             bscat=quote.xpath('//a[@class="badge-link"]//span[@class="cat-name"]//span[@class="cat-link"]//text()').extract()
    #             bestsellercategory=bscat[0]
    #         else:
    #             bestseller="No"
    #             bestsellercategory= None

            
    #         x=[]
            
    #         for imglst in response.xpath('//div[@id="altImages"]'):
    #             x=imglst.css("img").xpath('@src').getall()    
            
    #         product_info=json.dumps(product_info)  
    #         imgurl=','.join(str(y) for y in x) 
    #         sql = "INSERT INTO productdata(`product_name`, `list_price`, `price`, `rating`, `no_of_review`, `product_info`, `isamazonchoice`, `amazonsearchterm`, `isbestseller`, `bestsellercategory`, `image_url`) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
    #         val = (title,listprice,price,rating,NoOfRating,product_info,amazonchoice,AmazonChoiceSearchTerm,bestseller,bestsellercategory,imgurl)
    #         mycursor.execute(sql, val)
    #         mydb.commit()