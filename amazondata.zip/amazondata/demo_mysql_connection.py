import mysql.connector

# mydb = mysql.connector.connect(
#   host="dbMysql",
#   port="3306",
#   user="rdd",
#   password="rddtest",
#   # database="amazondata"
# )

# print(mydb)
# mycursor = mydb.cursor()
# # mycursor.execute("CREATE DATABASE amazondata")
mydb = mysql.connector.connect(
  host="dbMysql",
  port="3306",
  user="rdd",
  password="rddtest",
  database="amazondata"
)
mycursor = mydb.cursor()
mycursor.execute("CREATE TABLE productdata (product_name VARCHAR(255), list_price VARCHAR(25)  NULL, price VARCHAR(25)  NULL, rating VARCHAR(50)  NULL,no_of_review VARCHAR(50)  NULL,product_info VARCHAR(255)  NULL, isamazonchoice VARCHAR(15) NULL, amazonsearchterm VARCHAR(200)  NULL,isbestseller VARCHAR(15), bestsellercategory VARCHAR(200), image_url  text)")

# for x in mycursor:
#   print(x)