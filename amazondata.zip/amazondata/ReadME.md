this repository is for to scrap amazon search page extracted out product details steps of execution
1. Run docker
2. Download this repository in your directory
3. open terminal and go to directoy location where you put this repository
   type following command  
    "docker network create my-network" { In my example I used this network }
   verify network by using
   "docker network ls"
4. Install and run adminer and mysql
	here we installing adminer and mysql
	for adminer latest image for mysql  mysql:8.0.3 image
	type the following command
	"docker-compose up"
	this will take configuration from docker-compose.yml file'
	verify docker container for mysql and adminer is running by typing following command
  	"docker ps"

5. Now we install python and scrapy.
   here we have docker file for python and scrapy installation
   open new teminal and go to directory location wher you put this repository
	type the following command
	"docker build -t app-demo ." {here app-demo image name you can give any as you want)

6. run this image into containe as detach and in same network
   first get list of network
   "docker network ls"
   select network name which having  substring my-network in my case it is "amazondata_my-network"
   for communication between application and mysql we need to connect this container to this network at run time
   type the follwing command
	"docker run -it --network="amazondata_my-network" -d app-demo"
   verify that container is running type follwing command
   "docker ps"
   copy the running container id which having app-demo image in my case congtainer id is 01246c71ea07

7. now you ready to scrap amazon search page data
   type the follow command to create table in database
   "docker exec -it   01246c71ea07 python demo_mysql_connection.py"
   this will create table in amazondata
   you can verify this by following steps
   go to http:localhost:8080/
   you will adminer page where you need to enter mysql credential and database
   Enter following details
   system=select mysql
   server=dbMysql
   username=rdd
   password=rddtest
   database=amazondata
   
   after succesful entering to mysql database you will see a table productdata
   
   now extract page url for product for given url by typing following command
   "docker exec -it 01246c71ea07 scrapy crawl amma1 -a start_url='https://www.amazon.com/s?i=arts-crafts-intl-ship&bbn=4954955011&rh=n%3A4954955011%2Cp_36%3A1695-7000&qid=1592449077&rnid=2638325011&ref=sr_nr_p_36_3'"
   here start_url is url of amazon search page that you want to scrap
   this commmand create 2 file 
   1. paginationlinks.txt- contain pagination url for search page
   2. links txt - contain detailed product url (we use this file to extract data)
   
   now extract data from detaild product page stored in links.txt by typing following command
   "docker exec -it 01246c71ea07 scrapy crawl amma -a filename='links.txt'"
	
	this command will paser product page enter data into mysql file
  
   
   
    
